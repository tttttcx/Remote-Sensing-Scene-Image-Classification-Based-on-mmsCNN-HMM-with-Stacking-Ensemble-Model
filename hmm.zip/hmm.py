""" 
Created by ChengXiang (18175030250@163.com)
DATE: 2022/4/25 19:58
"""
# -*- coding: utf-8 -*-

import csv
import numpy as np
import pandas as pd
from hmmlearn.hmm import GMMHMM,GaussianHMM



if __name__ == '__main__':
    '''Training Part'''
    feature_label = pd.read_csv('RSSCN7.csv',header = None)
    stateList = [8,8,8,8,8,8,8]
    num_classes = 7
    testdata = []
    models   = []
    num = 10
    su_len = feature_label.shape[1]-1
    print(su_len)

    for item in range(0,num_classes):
        data = feature_label[feature_label.iloc[:,su_len] == item]
        data_set = data.iloc[:,0:su_len]

        n_samples = data.shape[0]/ num
        train_num = int(n_samples*0.85)*num

        df_train = data_set.iloc[0:train_num,:]
        df_test  = data_set.iloc[train_num:,:]
        testdata.append(df_test)

        n_hs = stateList[item]
        seq_train = np.ones(train_num // num)*num
        seq_train = seq_train.astype(int)
        print("data pre is ok!")

        model = GaussianHMM(n_components=n_hs, covariance_type='diag', min_covar=0.0001, n_iter=1000)
        model.fit(df_train, lengths=seq_train)
        models.append(model)
    print('successful train')

    '''Test Part'''
    y_score = []
    y_predict = []
    y_true = []

    for j in range(num_classes):
        y1_score = []
        tmp = []
        test = testdata[j]
        n_test = test.shape[0] // num
        score = []
        for _ in range(num_classes):
            score.append([])
        for i in range(n_test):
            sum = 0
            tmp = []
            for m in range(num_classes):
                y_tmp = models[m].score(test.iloc[num*i:num * (i + 1), :])
                tmp.append(y_tmp)
                sum += y_tmp

            for m in range(num_classes):
                y_tmp = models[m].score(test.iloc[num*i:num * (i + 1), :])
                y_tmp = y_tmp/sum
                score[m].append(y_tmp)
            y = tmp.index(max(tmp))
            y_predict.append(y)
            y_true.append(j)

            for k in range(num_classes):
                y1_score.append(score[k])
            y_score.append(y1_score)

    acc = 0
    for res in range(len(y_predict)):
        outputs = y_score[res]
        labels = np.mean(y_true[res])
        temp_data = np.append(outputs,labels)
        temp_data = temp_data.tolist()

        with open('train_stacking.csv', 'a+', encoding='UTF8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(temp_data)

        if y_predict[res] == y_true[res]:
            acc += 1
    print('Acc of Hmm: ', (acc / len(y_true)))

    print(type(y_predict))

